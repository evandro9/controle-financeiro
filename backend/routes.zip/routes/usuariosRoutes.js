const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../database/db');

router.post('/', async (req, res) => {
  const { nome, email, senha } = req.body;

  try {
    const senhaHash = await bcrypt.hash(senha, 10);
    const stmt = db.prepare(`INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)`);
    stmt.run(nome, email, senhaHash);
    res.status(201).json({ message: 'Usuário criado com sucesso' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao criar usuário' });
  }
});

module.exports = router;