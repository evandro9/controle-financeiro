const express = require('express');
const router = express.Router();
const db = require('../database/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const SECRET = process.env.JWT_SECRET;

router.post('/', async (req, res) => {
  const { usuario, senha } = req.body;
  console.log('Login recebido:', usuario, senha);
  console.log('SECRET usado no login:', SECRET);

  try {
    db.get('SELECT * FROM usuarios WHERE email = ?', [usuario], async (err, user) => {
      if (err) {
        console.error('Erro ao buscar usuário:', err);
        return res.status(500).json({ error: 'Erro ao buscar usuário' });
      }

      if (!user) {
        console.log('Usuário não encontrado:', usuario);
        return res.status(401).json({ error: 'Usuário não encontrado' });
      }

      const senhaCorreta = await bcrypt.compare(senha, user.senha);
      if (!senhaCorreta) {
        console.log('Senha incorreta para:', usuario);
        return res.status(401).json({ error: 'Senha incorreta' });
      }

      const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: '7d' });
      console.log('Login bem-sucedido');
      res.json({ token, nome: user.nome });
    });
  } catch (err) {
    console.error('Erro inesperado no login:', err);
    res.status(500).json({ error: 'Erro no login' });
  }
});

module.exports = router;
